


 body {
 margin: 0;
 background-color: black;
 overflow: hidden;
 }

 .cover-holder {
 margin: 0 auto;
 text-align: center;
 }
 


[![](https://lh3.googleusercontent.com/kmiTiqJroiVIDiEd-rQh4KdEJS1rSp0DAKeoNqjFniH0_mQ_L6E5VDk=w800-h533)](https://get.google.com/albumarchive/pwa/104275467866238183783/album/5864921004299977489)



