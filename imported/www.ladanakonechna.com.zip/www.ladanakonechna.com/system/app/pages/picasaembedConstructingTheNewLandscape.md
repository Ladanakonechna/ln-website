


 body {
 margin: 0;
 background-color: black;
 overflow: hidden;
 }

 .cover-holder {
 margin: 0 auto;
 text-align: center;
 }
 


[![](https://lh3.googleusercontent.com/Ttc-j_tpTwZVX1CscjcEdn9zw50xdiETDhyIdjgrgT144iGJqWWvw8Hu82lkl3BAR7MKx-R5mgV2h1o=w800-h533)](https://get.google.com/albumarchive/pwa/104275467866238183783/album/5822946656465871729?authKey=CPTnprK_hcCCmQE)



