


 body {
 margin: 0;
 background-color: black;
 overflow: hidden;
 }

 .cover-holder {
 margin: 0 auto;
 text-align: center;
 }
 


[![](https://lh3.googleusercontent.com/8Aa_S6veikQrhrUqjz1dmdp5jO_jqjX-iVBLIqO1dA0OvKskbHDc4_0=w800-h533)](https://get.google.com/albumarchive/pwa/104275467866238183783/album/5569743910074895441)



