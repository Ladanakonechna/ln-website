


 body {
 margin: 0;
 background-color: black;
 overflow: hidden;
 }

 .cover-holder {
 margin: 0 auto;
 text-align: center;
 }
 


[![](https://lh3.googleusercontent.com/gK368wzJA15ObZ_FQJXpWGL_bjzgD7AiLz5tobPF8wTWhIxcROY21fVgdfGxrwJGfun4vnmMZaZAQLI=w800-h533)](https://get.google.com/albumarchive/pwa/104275467866238183783/album/5822942783939338721?authKey=CJy2hOC5_OXBhwE)



