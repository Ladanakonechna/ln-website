


 body {
 margin: 0;
 background-color: black;
 overflow: hidden;
 }

 .cover-holder {
 margin: 0 auto;
 text-align: center;
 }
 


[![](https://lh3.googleusercontent.com/_sIZ0VzwCb4fZ2wvKsFaUyw-_fKlfE7G5A1L3VaRrzwlgqYjELpFfnWw1c-gOVucBl0dumZTSZSQzY4=w800-h533)](https://get.google.com/albumarchive/pwa/104275467866238183783/album/5499707435588736321?authKey=COSGjqmQ59HNqQE)



