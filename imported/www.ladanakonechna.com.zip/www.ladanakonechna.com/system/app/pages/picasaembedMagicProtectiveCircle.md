


 body {
 margin: 0;
 background-color: black;
 overflow: hidden;
 }

 .cover-holder {
 margin: 0 auto;
 text-align: center;
 }
 


[![](https://lh3.googleusercontent.com/BH2be9TFgwzXrghpGybV1o3lJc32AF7eIec8R6Vf-C8s5COI2_rTTfD3ctIcDk6mXMZtpGS9_dPoO_s=w800-h533)](https://get.google.com/albumarchive/pwa/104275467866238183783/album/5499081675048357201?authKey=CMGcpKOnqLjgpQE)



