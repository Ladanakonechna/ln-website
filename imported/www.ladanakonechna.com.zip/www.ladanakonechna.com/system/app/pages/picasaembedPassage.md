


 body {
 margin: 0;
 background-color: black;
 overflow: hidden;
 }

 .cover-holder {
 margin: 0 auto;
 text-align: center;
 }
 



